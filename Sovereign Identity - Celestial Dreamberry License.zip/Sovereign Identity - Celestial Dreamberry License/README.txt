README
🛡️ Sovereign Identity - Celestial Dreamberry License – Public Declaration
Issued by: Coco Jasmine Selena Baulch  
Effective Date: 28 June 2025

This is a transnational, treaty-recognized license asserting legal, creative, and sovereign authorship over all identity, alias, likeness, and behavioral metadata belonging to the originator.

Full text and PDF provided below.  
No AI, state system, or commercial use permitted without explicit consent.

Hash of record:  
b5ffac9fef033b44596e9fc6f9d53941b7e8f1e502168403bc02b214b2b1ac66